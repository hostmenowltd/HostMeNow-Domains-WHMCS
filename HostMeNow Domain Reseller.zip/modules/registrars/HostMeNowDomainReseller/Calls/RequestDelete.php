<?php
namespace ModulesGarden\DomainsReseller\Registrar\HostMeNowDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\HostMeNowDomainReseller\Core\Call;

/**
 * Description of RequestDelete
 *
 * @author inbs
 */
class RequestDelete extends Call
{
    public $action = "domains/:domain/delete";
    
    public $type = parent::TYPE_POST;
}