<?php
namespace ModulesGarden\DomainsReseller\Registrar\HostMeNowDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\HostMeNowDomainReseller\Core\Call;

/**
 * Description of RegisterNameServer
 *
 * @author inbs
 */
class RegisterNameServer extends Call
{
    public $action = "domains/:domain/nameservers/register";
    
    public $type = parent::TYPE_POST;
}