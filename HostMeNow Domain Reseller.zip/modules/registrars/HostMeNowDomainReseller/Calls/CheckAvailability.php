<?php
namespace ModulesGarden\DomainsReseller\Registrar\HostMeNowDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\HostMeNowDomainReseller\Core\Call;

/**
 * Description of CheckAvailability
 *
 * @author inbs
 */
class CheckAvailability extends Call
{
    public $action = "domains/lookup";
    
    public $type = parent::TYPE_POST;
}