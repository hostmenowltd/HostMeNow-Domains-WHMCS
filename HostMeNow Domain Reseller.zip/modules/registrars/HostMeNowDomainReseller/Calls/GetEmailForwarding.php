<?php
namespace ModulesGarden\DomainsReseller\Registrar\HostMeNowDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\HostMeNowDomainReseller\Core\Call;

/**
 * Description of GetEmailForwarding
 *
 * @author inbs
 */
class GetEmailForwarding extends Call
{
    public $action = "domains/:domain/email";
    
    public $type = parent::TYPE_GET;
}