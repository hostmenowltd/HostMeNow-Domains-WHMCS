<?php
namespace ModulesGarden\DomainsReseller\Registrar\HostMeNowDomainReseller\Calls;
use ModulesGarden\DomainsReseller\Registrar\HostMeNowDomainReseller\Core\Call;

/**
 * Description of GetNameServers
 *
 * @author inbs
 */
class SaveEmailForwarding extends Call
{
    public $action = "domains/:domain/email";
    
    public $type = parent::TYPE_POST;
}